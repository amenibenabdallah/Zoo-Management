import java.util.TreeMap;

public class Zoo {
    Animal [] animals;
    String name,city;
    int nbcages;
    int countAnimal=0;

    public void displayZoo(){
        System.out.println("name: "+name+", "+" city: "+city+", "+" number of cages: "+nbcages);
    }
    public void displayAnimeaux(){
        String str="";
        for(int i=0;i<countAnimal;i++){
            str=str+animals[i].name+", ";
        }
        System.out.println("les animaux dans cette zoo sont : "+str);
    }

    public String toString(){
        if (countAnimal == 0) {
            return "name: " + name + ", city: " + city + ", number of cages: " + nbcages + ", there are no animals in this zoo.";
        }
        String str="";
        for(int i=0;i<countAnimal;i++){
                str=str+animals[i]+", ";
        }
        return "name: "+name+", city:"+city+", number of cages: "+nbcages+", Animals of this zoo are: "+str;
    };

    int searchAnimal(Animal animal){
        for(int i=0;i<countAnimal;i++){
            if(animals[i].name==animal.name){
                return i;
            }
        }
        return -1;

    }
    boolean addAnimal(Animal animal){
        if(countAnimal<nbcages){
            if(searchAnimal(animal)==-1){
                animals[countAnimal]=animal;
                countAnimal++;
                return true;
        }
        }
    return false;
    }

    boolean removeAnimal(Animal animal){
        int index=searchAnimal(animal);
        if(index==-1){
            return false;
        }
        for(int i=0;i<countAnimal;i++){
            animals[index]=animals[index+1];
            countAnimal=countAnimal-1;
        }
        return true;
    }

    Zoo(){}
    Zoo(String name,String city,int nbcages){
        this.animals=new Animal[nbcages];
        this.name=name;
        this.city=city;
        this.nbcages=nbcages;
    }

}
