import java.util.Scanner;
public class ZooManagement {
    public static void main(String[] args) {
        Scanner scanner=new Scanner(System.in);
        System.out.println("donner un nombre de cages");
        int nbCages=scanner.nextInt();
        System.out.println("donner un zoo name");
        scanner.nextLine();
        String zooName=scanner.nextLine();
        System.out.println(zooName+" comporte "+nbCages);

        Animal test=new Animal();
        test.name="testName";
        test.family="testFamily";
        test.isMammal=false;

        Animal lion=new Animal("mammal","lion1",3,true);
        Zoo myZoo=new Zoo("fun Zoo","LA",25);
        myZoo.displayZoo();
        System.out.println(myZoo);
        System.out.println(lion);
        System.out.println(myZoo.addAnimal(lion));
        System.out.println(myZoo.addAnimal(lion));
        myZoo.addAnimal(test);

        myZoo.displayAnimeaux();

        System.out.println("test search: "+myZoo.searchAnimal(lion));
        System.out.println("test remove: "+myZoo.removeAnimal(lion));
        System.out.println("zoo after remove animal: "+myZoo);
    }
}
