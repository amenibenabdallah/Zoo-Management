public class Animal {
    String family,name;
    int age;
    boolean isMammal;

    public String toString(){
        return "family: "+family+", name: "+name+", isMammal: "+isMammal;
    }
    Animal(){}
    Animal(String family,String name,int age,boolean isMammal){
        this.family=family;
        this.name=name;
        this.age=age;
        this.isMammal=isMammal;
    }
}
